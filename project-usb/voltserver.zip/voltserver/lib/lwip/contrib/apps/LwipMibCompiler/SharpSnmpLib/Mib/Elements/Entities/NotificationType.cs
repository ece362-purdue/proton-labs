
namespace Lextm.SharpSnmpLib.Mib.Elements.Entities
{
    public sealed class NotificationType : EntityBase
    {
        public NotificationType(IModule module, SymbolList preAssignSymbols, ISymbolEnumerator symbols)
            : base(module, preAssignSymbols, symbols)
        {
        }
   }
}